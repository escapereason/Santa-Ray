[Back to Master Repair Plan](../master-repair-plan.md)

# Pest/Fungus Remediation Contractor Plan

**Property:** 757 Santa Ray Avenue, Oakland, CA 94610  
**Total Estimated Cost:** $80,525 + permits  
**Priority:** 🔴 CRITICAL  
**Required:** Licensed Pest Control Operator

---

## Summary of Pest/Fungus Remediation

This section is under construction. Please refer to the [Master Repair Plan](../master-repair-plan.md) for the detailed breakdown of the pest and fungus remediation work.