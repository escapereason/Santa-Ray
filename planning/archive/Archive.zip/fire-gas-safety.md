# Fire & Gas Safety Repair Plan

**Property:** 757 Santa Ray Avenue, Oakland, CA 94610  
**Total Estimated Cost:** $30 - $60  
**Priority:** 🔴 All items are CRITICAL safety hazards.  

---

## Summary of Fire & Gas Safety Repairs

| Priority | Issue | Location | Est. Cost | Recommendation |
|----------|-------|----------|-----------|----------------|
| **CRITICAL** | Missing CO detectors | Lower unit & in-law | $30-60 | DIY |

---

## 🔴 CRITICAL PRIORITY (IMMEDIATE FIX)

### 1. Missing Carbon Monoxide (CO) Detectors
- **Priority:** CRITICAL (Life Safety Hazard)
- **Locations:** Lower unit and in-law apartment.
- **Problem:** There are no CO detectors installed in units with fuel-burning appliances (furnace, water heater, stove). CO is an odorless, colorless gas that can be lethal. California law requires CO detectors in all dwelling units.
- **Recommendation:** **DIY**
- **DIY Potential:** High. This is one of the most important and easiest safety upgrades you can make.

---
#### **DIY Guide: Installing CO Detectors**

**What to Look For:**

*   **Type:** For simplicity and reliability, use **10-year sealed battery** CO detectors. This means no low-battery chirps for a decade. Combination smoke and CO detectors are also a great choice to upgrade safety.
*   **Placement is Key:** CO mixes with air, so detectors can be placed at various heights. The manufacturer's instructions are your primary guide, but here are the code requirements:
    *   **Outside Sleeping Areas:** Install a detector in the hallway or area directly outside of bedrooms.
    *   **On Every Level:** At least one detector on each floor of the home, including basements.
*   **Avoid:**
    *   **Garages, kitchens, and bathrooms:** Steam, humidity, and cooking fumes can cause false alarms. Keep detectors at least 15 feet away from cooking appliances.
    *   **Direct Sunlight or Near Heating Vents:** Avoid areas with turbulent air or temperature fluctuations.
    *   **Behind Furniture or Curtains:** The detector must have clear air access.

**Step-by-Step Instructions:**

1.  **Choose Your Locations:** Identify the best spots in the lower unit and the in-law apartment based on the guidelines above.
2.  **Unpack and Activate:** Remove the detector from the packaging. Most 10-year models are activated by twisting them onto their mounting plate or pulling a tab. It should beep or have a light to confirm it's on.
3.  **Mount the Plate:**
    *   Hold the mounting plate against the wall or ceiling in your chosen location.
    *   Use a pencil to mark the screw holes.
    *   Use a drill or screwdriver to install the included screws and anchors.
4.  **Attach the Detector:** Twist the CO detector onto the mounting plate until it clicks into place.
5.  **Test the Unit:** Press the "Test" button on the detector. It should sound a loud alarm. This confirms the unit is working correctly. Test your detectors monthly.