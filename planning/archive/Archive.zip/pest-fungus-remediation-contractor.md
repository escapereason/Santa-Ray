# Pest & Fungus Remediation Contractor Plan

**Property:** 757 Santa Ray Avenue, Oakland, CA 94610  
**Total Estimated Cost:** $80,525 + $6,950 permits = $87,475  
**Priority:** 🔴 CRITICAL - Section I findings require immediate attention  
**Required:** Licensed Pest Control Operator (CA License Required)

---

## 🚨 CRITICAL DISCOVERY: EXTENSIVE FUNGUS DAMAGE

The pest inspection revealed **$80,525 in critical fungus damage** throughout the property, dramatically increasing the total project scope. This work cannot be delayed and must be completed before winter weather.

### Project Overview
| **Total Remediation Cost** | **$80,525** |
|------------------------|-------------|
| **Building Permits Required** | **$6,950** |
| **Timeline** | **30 days** |
| **Must Complete Before** | **Winter rainy season** |

---

## CRITICAL SECTION I FINDINGS - IMMEDIATE REMEDIATION REQUIRED

| Issue | Location | Scope | Treatment Required | Est. Cost |
|-------|----------|-------|-------------------|-----------|
| **Fungus-infected debris** | Accessible subarea | Remove all debris of rakeable size and larger | Licensed Pest Control - debris removal and disposal | $50 |
| **Front porch/stairs fungus** | Wood framing beneath concrete porch/stairs | Remove insulation/sheetrock, repair fungus damaged framing with pressure treated douglas fir, Timbor fungicide treatment, reinstall materials, waterproofing | Licensed Pest Control + General Contractor + Waterproofing | $14,950 |
| **Side stairs handrail** | Side stairs handrail post | Repair existing handrail to eliminate fungus damage | Licensed Pest Control | $175 |
| **Rear wooden porch** | Rear wooden porch and framing | Complete porch and framing repair to eliminate fungus damage | Licensed Pest Control + General Contractor | $2,950 |
| **Carport support posts** | Carport support posts | Repair posts to eliminate fungus damage, prime paint disturbed areas | Licensed Pest Control + General Contractor | $6,950 |
| **Carport framing/siding** | Carport T1-11 siding and framing | Cut out fungus damaged wood, replace with new material, Tim-Bor treatment | Licensed Pest Control + General Contractor | Included w/ support posts |
| **Side deck and stairs** | Side wooden deck and stairs | Complete deck/stairs repair to eliminate fungus infection | Licensed Pest Control + General Contractor | $5,650 |
| **Main unit window sashes** | Large bedroom windows and sills | Remove/replace fungus damaged wood window sashes with new prime painted sashes, repair sills/framing | Licensed Pest Control + Window Contractor | $9,850 |
| **French door subfloor** | Subfloor adjacent to lower french doors | Repair fungus damage to subflooring and framing | Licensed Pest Control + General Contractor | $2,750 |
| **Side French doors** | Side French doors at fascia | Remove/replace fungus damaged doors, framing, and sill with new prime painted units | Licensed Pest Control + General Contractor | $12,650 |
| **Exterior window sashes** | Seven single lite fixed exterior windows | Remove/replace fungus damaged sashes with new prime painted sashes | Licensed Pest Control + Window Contractor | $4,950 |
| **Lower rear French doors** | Lower rear French doors | Remove/replace fungus damaged doors, framing, and sill with new prime painted units | Licensed Pest Control + General Contractor | $12,650 |

### **Total Section I Critical Work: $73,575**

---

## HIGH PRIORITY SECTION II FINDINGS - PROFESSIONAL ASSESSMENT REQUIRED

| Issue | Location | Scope | Treatment Required | Contractor |
|-------|----------|-------|-------------------|-----------|
| **Past moisture intrusion** | Accessible subarea and basement | Investigation and drainage correction | Drainage Contractor + Waterproofing | Professional Assessment Required |
| **Loose toilet** | Main bathroom | Professional resetting, subfloor inspection for damage | Licensed Plumber | See [Plumbing Contractor Plan](../contractor/plumbing-repairs-contractor.md) |
| **Cracked dining window** | Dining room | Window repair to prevent moisture intrusion | Licensed Window Repair | Professional Assessment Required |

---

## MEDIUM PRIORITY SECTION II FINDINGS - ONGOING MONITORING

| Issue | Location | Scope | Treatment Required | Est. Cost |
|-------|----------|-------|-------------------|-----------|
| **Stress crack in stucco** | Front porch buttress wall | Seal crack, monitor for settlement | General Contractor | Professional Assessment Required |
| **Poor subarea ventilation** | Subarea ventilation system | Remove louvered screens, install wire mesh, add vents | General Contractor/Handyman | Professional Assessment Required |
| **Water-stained hardwood** | Dining room and various locations | Floor refinishing, investigate stain causes | Flooring Specialist | Professional Assessment Required |
| **Deteriorated vanity** | Lower main bathroom | Vanity replacement and sealing | General Contractor | Professional Assessment Required |
| **Subarea access deterioration** | Exterior subarea access | Maintain exterior wood sealing | Handyman/Owner | Professional Assessment Required |

---

## CONTRACTOR REQUIREMENTS

### Essential Licensed Contractors Required

#### **Primary Contractor - Licensed Pest Control Operator**
- **California Structural Pest Control License** (Branch 2 or 3)
- **Tim-Bor application certification** (disodium octaborate tetrahydrate)
- **Fungus remediation expertise** with wood-destroying organisms
- **Liability insurance** minimum $2M for structural work
- **Workers compensation** coverage
- **HazMat handling certification** for fungicide application

#### **Supporting Contractors Required**
- **General Contractor** (CA License B or appropriate specialty)
  - Structural framing and subfloor repair
  - Door and window framing installation
  - Deck and porch reconstruction
- **Window Contractor** (CA License C-51 or specialty)
  - Window sash replacement and installation
  - Weatherproofing and moisture barrier installation
- **Waterproofing Contractor** (CA License C-39)
  - Moisture intrusion investigation and remediation
  - Waterproofing systems for long-term protection
- **Drainage Contractor**
  - Subarea moisture source investigation
  - Drainage system design and installation

### Recommended Qualifications
- **Fungus remediation experience** with similar structures
- **Historical building expertise** for appropriate material matching
- **Moisture investigation specialists** for root cause analysis
- **Insurance restoration experience** for potential claims coordination

---

## PERMITTING REQUIREMENTS

### **CRITICAL: Building Permits Required**
**Estimated permit fees: $6,950 (minimum $1,000 + $200 admin fee)**

#### Required Permits Include:
- **Structural repairs** for all framing work
- **Window and door replacements**
- **Deck and porch reconstruction**
- **Subfloor repairs and replacements**
- **Moisture barrier installations**

#### Permit Process Timeline:
- **Days 1-3:** Permit application preparation and submission
- **Days 4-7:** Plan review and approval (expedited if possible)
- **Day 8:** Permits issued, work can commence
- **Ongoing:** Required inspections at various stages
- **Final:** Completion inspection and permits closed

#### Inspection Schedule:
- **Foundation/framing inspection** before covering work
- **Moisture barrier inspection** before finish work
- **Final inspection** upon project completion

---

## PROJECT TIMELINE - 30 DAYS CRITICAL PATH

### **Phase 1: Emergency Preparation (Days 1-7)**
- **Days 1-3:** Building permit applications and contractor coordination
- **Days 4-7:** Permit approval and material procurement
- **Site preparation** and safety measures implementation

### **Phase 2: Critical Structural Work (Days 8-23)**
- **Days 8-15:** Critical fungus remediation (front porch, carport, decks)
  - Front porch/stairs framing repair ($14,950)
  - Carport support posts and framing ($6,950)
  - Side deck and stairs reconstruction ($5,650)
- **Days 16-23:** Window and door replacements
  - Main unit window sashes ($9,850)
  - Side French doors replacement ($12,650)
  - Lower rear French doors replacement ($12,650)
  - Exterior window sashes ($4,950)

### **Phase 3: Completion and Waterproofing (Days 24-30)**
- **Days 24-27:** Subfloor repairs and remaining structural work
  - French door subfloor repair ($2,750)
  - Rear wooden porch repair ($2,950)
  - Side stairs handrail repair ($175)
- **Days 28-30:** Final Tim-Bor treatment and site cleanup
  - Debris removal ($50)
  - Final fungicide application
  - Site restoration and cleanup

---

## SCOPE OF WORK DETAILS

### **Tim-Bor Fungicide Treatment**
- **Application by licensed pest control operator only**
- **Disodium Octaborate Tetrahydrate** EPA-approved treatment
- **Penetrating treatment** for all affected wood members
- **Preventive application** to adjacent areas
- **Re-treatment schedule** as recommended by pest control operator

### **Structural Repair Standards**
- **Pressure-treated Douglas Fir** for all replacement framing
- **Matching existing dimensions** and structural requirements
- **Proper moisture barriers** and waterproofing integration
- **Code-compliant structural connections**
- **Prime-painted finish** for all exposed wood surfaces

### **Moisture Prevention Integration**
- **Identify and eliminate moisture sources** before repairs
- **Install proper drainage** and waterproofing systems
- **Ventilation improvements** to prevent future moisture issues
- **Coordinate with plumbing repairs** to address leaks

---

## COST BREAKDOWN

### Section I Critical Work (Required)
| Category | Cost Range |
|----------|-----------|
| Front porch/stairs fungus repair | $14,950 |
| Carport support posts and framing | $6,950 |
| Side deck and stairs | $5,650 |
| Main unit window sashes | $9,850 |
| Side French doors | $12,650 |
| Lower rear French doors | $12,650 |
| Exterior window sashes | $4,950 |
| French door subfloor | $2,750 |
| Rear wooden porch | $2,950 |
| Side stairs handrail | $175 |
| Debris removal | $50 |
| **Section I Subtotal** | **$73,575** |

### Additional Required Costs
| Item | Cost Range |
|------|-----------|
| Licensed pest control coordination | $6,950 |
| **Additional Subtotal** | **$6,950** |

### Permits and Fees
| Item | Cost Range |
|------|-----------|
| Building permits (required) | $6,950 |
| **Permit Subtotal** | **$6,950** |

### **TOTAL PEST/FUNGUS REMEDIATION: $87,475**

---

## CRITICAL DEPENDENCIES

### **Before Work Can Begin:**
- **Licensed Pest Control Operator** must be contracted first
- **Building permits** must be approved before structural work
- **Tim-Bor fungicide** must be applied by licensed operator only
- **Moisture source investigation** must be completed before repairs
- **Waterproofing contractor** must be engaged for long-term solution

### **Coordination Requirements:**
- **General contractor** must work under pest control operator oversight
- **Window contractor** must coordinate with structural repairs
- **All work** must follow pest control operator specifications
- **Inspections** must be scheduled with appropriate authorities

---

## INSURANCE CONSIDERATIONS

### **Document Everything Before Work Begins:**
- **Photograph all damage** extensively before remediation
- **Video documentation** of affected areas
- **Professional assessment reports** from all contractors
- **Moisture readings** and environmental testing

### **Potential Coverage Areas:**
- **Sudden water damage** leading to fungus growth
- **Structural damage** from covered water events
- **Temporary living expenses** if units become uninhabitable
- **Emergency stabilization** costs for immediate safety

### **Insurance Claim Process:**
- **Contact insurance immediately** before beginning work
- **Get adjuster inspection** of all damage
- **Obtain multiple contractor estimates** for comparison
- **Document all moisture sources** and timeline of damage

---

## FUTURE MAINTENANCE REQUIREMENTS

### **Mandatory Post-Remediation:**
- **Licensed pest control inspections** every 6 months for 2 years
- **Tim-Bor retreatment schedule** as recommended by pest control operator
- **Annual comprehensive pest inspections** permanently recommended
- **Moisture monitoring** of previously affected areas

### **Preventive Maintenance:**
- **Maintain all exterior wood surfaces** with quality sealants and paint
- **Address moisture sources permanently** to prevent fungus recurrence
- **Install and maintain proper drainage** and waterproofing systems
- **Regular subarea ventilation** maintenance and monitoring

### **Long-term Monitoring:**
- **Bi-annual moisture readings** in previously affected areas
- **Visual inspections** of all repaired structural elements
- **Immediate response** to any signs of moisture intrusion
- **Professional assessment** at first sign of recurring issues

---

## EMERGENCY CONTACT PROTOCOLS

### **During Remediation Work:**
- **24/7 contractor contact** for emergency situations
- **Building permit hotline** for inspection scheduling
- **Pest control operator** emergency contact for safety issues
- **Insurance adjuster** contact for claim-related questions

This extensive fungus remediation project is critical for the structural integrity and habitability of the property. Delays could result in exponentially increasing damage and costs.